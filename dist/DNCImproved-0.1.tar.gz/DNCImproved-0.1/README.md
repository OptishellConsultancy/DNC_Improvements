This repo is a cleanup
of Deepmind DNC - Differential neural computer
Namely to help allow additional formats
and dyamaically optimize towards the data structure.


Objectives include:

Bio data for donars, against quality of life and supportive data.

Modelling electrostatic guided Ink
particles through CIG.

//Ags guide:


//Sources:

https://deepmind.com/blog/differentiable-neural-computers/

