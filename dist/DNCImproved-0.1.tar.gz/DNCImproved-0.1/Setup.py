from setuptools import setup, find_packages
setup(
    name="DNCImproved",
    version="0.1",
    packages=find_packages(),
     scripts=['access.py.py','addressing.py'],
)